import React from 'react';
import { BookOpen, LayoutDashboard, Brain, Timer, MessageSquareText } from 'lucide-react';
import { cn } from '@/lib/utils';
import { motion } from 'motion/react';

type Page = 'dashboard' | 'notes' | 'flashcards' | 'focus' | 'tutor';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: Page;
  onPageChange: (page: Page) => void;
}

export function Layout({ children, currentPage, onPageChange }: LayoutProps) {
  const navItems = [
    { id: 'dashboard', label: 'Dashboard', icon: LayoutDashboard },
    { id: 'notes', label: 'Smart Notes', icon: BookOpen },
    { id: 'flashcards', label: 'Flashcards', icon: Brain },
    { id: 'focus', label: 'Focus Timer', icon: Timer },
    { id: 'tutor', label: 'AI Tutor', icon: MessageSquareText },
  ] as const;

  return (
    <div className="flex h-screen bg-[#0f172a] text-white font-sans overflow-hidden relative">
      {/* Mesh Gradient Background */}
      <div className="absolute inset-0 pointer-events-none z-0">
        <div className="absolute top-[-10%] left-[-10%] w-[40%] h-[40%] bg-purple-600/30 rounded-full blur-[120px]"></div>
        <div className="absolute bottom-[-10%] right-[-10%] w-[50%] h-[50%] bg-blue-600/20 rounded-full blur-[120px]"></div>
        <div className="absolute top-[20%] right-[10%] w-[30%] h-[30%] bg-indigo-500/20 rounded-full blur-[100px]"></div>
      </div>

      {/* Sidebar */}
      <aside className="w-64 bg-white/5 backdrop-blur-2xl border-r border-white/10 flex flex-col pt-6 pb-4 z-10 relative">
        <div className="px-6 mb-10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 flex items-center justify-center bg-gradient-to-br from-indigo-500 to-purple-600 rounded-lg shadow-lg shadow-indigo-500/20">
              <BookOpen className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold tracking-tight">Lumina Study</span>
          </div>
        </div>

        <nav className="flex-1 px-4 space-y-2 relative">
          {navItems.map((item) => {
            const isActive = currentPage === item.id;
            return (
              <button
                key={item.id}
                onClick={() => onPageChange(item.id)}
                className={cn(
                  "flex items-center gap-3 w-full px-4 py-3 rounded-xl text-left transition-colors relative text-sm font-medium",
                  isActive ? "text-white" : "text-slate-400 hover:bg-white/5 hover:text-white"
                )}
              >
                {isActive && (
                   <motion.div
                     layoutId="sidebar-active"
                     className="absolute inset-0 bg-white/10 border border-white/10 rounded-xl"
                     initial={false}
                     transition={{ type: "spring", stiffness: 350, damping: 30 }}
                   />
                )}
                <item.icon className={cn("w-5 h-5 relative z-10", isActive ? "text-indigo-400" : "")} />
                <span className="relative z-10">{item.label}</span>
              </button>
            )
          })}
        </nav>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col h-screen overflow-hidden relative z-10">
        {children}
      </main>
    </div>
  );
}
