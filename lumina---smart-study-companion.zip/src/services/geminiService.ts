import { GoogleGenAI, Type } from "@google/genai";

const getAI = () => {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error("GEMINI_API_KEY is missing. Please configure it in the settings.");
  }
  return new GoogleGenAI({ apiKey });
};

export async function generateFlashcards(text: string) {
  const ai = getAI();
  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: `Analyze the following study notes and extract the most important concepts into a list of concise flashcards with a 'front' (question or concept) and 'back' (answer or definition).\n\nNotes: ${text}`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.ARRAY,
        items: {
          type: Type.OBJECT,
          properties: {
            front: { type: Type.STRING, description: "The term, question, or concept" },
            back: { type: Type.STRING, description: "The definition, answer, or explanation" }
          },
          required: ["front", "back"]
        }
      }
    }
  });

  const rawText = response.text || "[]";
  try {
    return JSON.parse(rawText) as { front: string; back: string }[];
  } catch (e) {
    console.error("Failed to parse flashcards", e);
    return [];
  }
}

export async function getStudyMotivation() {
  try {
      const ai = getAI();
      const response = await ai.models.generateContent({
        model: "gemini-3-flash-preview",
        contents: "Give me a single, short, encouraging, and highly motivating sentence to keep studying. Do not include quotes or author names, just the message."
      });
      return response.text?.trim() || "You are doing great! Keep going.";
  } catch(e) {
      return "You are doing great! Keep going.";
  }
}

export async function askTutor(context: string, question: string, chatHistory: { role: "user" | "model", text: string }[] = []) {
  const ai = getAI();
  
  const formattedHistory = chatHistory.length > 0 ? chatHistory.map(m => `${m.role === 'user' ? 'Student' : 'Tutor'}: ${m.text}`).join('\n') + '\n' : '';

  const response = await ai.models.generateContent({
    model: "gemini-3.1-pro-preview",
    contents: `You are an expert AI tutor. 
Context from the student's current notes (if any):
${context || 'No notes currently open.'}

Previous conversation:
${formattedHistory}

Student Question:
${question}

Provide a clear, helpful, and concise answer to the student's question. Use markdown formatting.`
  });

  return response.text || "I'm not sure about that. Could you rephrase your question?";
}
