/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider } from '@/store/AppContext';
import { Layout } from '@/components/Layout';
import { Dashboard } from '@/pages/Dashboard';
import { NotesPage } from '@/pages/NotesPage';
import { FlashcardsPage } from '@/pages/FlashcardsPage';
import { FocusTimer } from '@/pages/FocusTimer';
import { TutorPage } from '@/pages/TutorPage';

export default function App() {
  const [currentPage, setCurrentPage] = useState<'dashboard' | 'notes' | 'flashcards' | 'focus' | 'tutor'>('dashboard');

  return (
    <AppProvider>
      <Layout currentPage={currentPage} onPageChange={setCurrentPage}>
        {currentPage === 'dashboard' && <Dashboard onNavigate={setCurrentPage} />}
        {currentPage === 'notes' && <NotesPage />}
        {currentPage === 'flashcards' && <FlashcardsPage />}
        {currentPage === 'focus' && <FocusTimer />}
        {currentPage === 'tutor' && <TutorPage />}
      </Layout>
    </AppProvider>
  );
}
