import React, { createContext, useContext, useState, useEffect } from 'react';

export type Flashcard = {
  id: string;
  front: string;
  back: string;
};

export type Note = {
  id: string;
  title: string;
  content: string;
  flashcards: Flashcard[];
  lastModified: number;
};

type AppContextType = {
  notes: Note[];
  addNote: (note: Omit<Note, 'id' | 'lastModified'>) => void;
  updateNote: (id: string, noteData: Partial<Omit<Note, 'id' | 'lastModified'>>) => void;
  deleteNote: (id: string) => void;
  timerStats: {
    totalSessions: number;
    totalMinutes: number;
  };
  addTimerSession: (minutes: number) => void;
};

const AppContext = createContext<AppContextType | undefined>(undefined);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [notes, setNotes] = useState<Note[]>(() => {
    const saved = localStorage.getItem('lumina_notes');
    return saved ? JSON.parse(saved) : [];
  });
  const [timerStats, setTimerStats] = useState({ totalSessions: 0, totalMinutes: 0 });

  useEffect(() => {
    localStorage.setItem('lumina_notes', JSON.stringify(notes));
  }, [notes]);

  useEffect(() => {
    const savedStats = localStorage.getItem('lumina_timer');
    if (savedStats) setTimerStats(JSON.parse(savedStats));
  }, []);

  const addTimerSession = (minutes: number) => {
    const newStats = {
      totalSessions: timerStats.totalSessions + 1,
      totalMinutes: timerStats.totalMinutes + minutes
    };
    setTimerStats(newStats);
    localStorage.setItem('lumina_timer', JSON.stringify(newStats));
  };

  const addNote = (noteData: Omit<Note, 'id' | 'lastModified'>) => {
    const newNote: Note = {
      ...noteData,
      id: crypto.randomUUID(),
      lastModified: Date.now()
    };
    setNotes([newNote, ...notes]);
  };

  const updateNote = (id: string, noteData: Partial<Omit<Note, 'id' | 'lastModified'>>) => {
    setNotes(notes.map(n => n.id === id ? { ...n, ...noteData, lastModified: Date.now() } : n));
  };

  const deleteNote = (id: string) => {
    setNotes(notes.filter(n => n.id !== id));
  };

  return (
    <AppContext.Provider value={{ notes, addNote, updateNote, deleteNote, timerStats, addTimerSession }}>
      {children}
    </AppContext.Provider>
  );
}

export function useAppContext() {
  const context = useContext(AppContext);
  if (!context) throw new Error("useAppContext must be used within AppProvider");
  return context;
}
