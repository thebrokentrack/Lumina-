import React, { useState } from 'react';
import { useAppContext, Note } from '@/store/AppContext';
import { generateFlashcards } from '@/services/geminiService';
import { motion, AnimatePresence } from 'motion/react';
import { Plus, Trash2, Wand2, Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';

export function NotesPage() {
  const { notes, addNote, updateNote, deleteNote } = useAppContext();
  const [activeNoteId, setActiveNoteId] = useState<string | null>(notes[0]?.id || null);
  const [isGenerating, setIsGenerating] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const activeNote = notes.find(n => n.id === activeNoteId);
  const filteredNotes = notes.filter(n => n.title.toLowerCase().includes(searchQuery.toLowerCase()) || n.content.toLowerCase().includes(searchQuery.toLowerCase()));

  const handleCreateNote = () => {
    const newNote = {
      title: 'New Note',
      content: '',
      flashcards: []
    };
    addNote(newNote);
  };

  const handleGenerateCards = async () => {
    if (!activeNote || !activeNote.content.trim()) return;
    setIsGenerating(true);
    try {
      const cards = await generateFlashcards(activeNote.content);
      const newFlashcards = cards.map(c => ({ ...c, id: crypto.randomUUID() }));
      updateNote(activeNote.id, { flashcards: [...(activeNote.flashcards || []), ...newFlashcards] });
    } catch (e) {
      console.error(e);
      alert("Failed to generate flashcards.");
    } finally {
      setIsGenerating(false);
    }
  };

  return (
    <div className="flex h-full w-full text-white bg-transparent">
      {/* Notes List */}
      <div className="w-80 border-r border-white/10 flex flex-col bg-white/5 backdrop-blur-2xl z-10 relative">
        <div className="p-6 border-b border-white/10">
          <button 
            onClick={handleCreateNote}
            className="w-full flex items-center justify-center gap-2 bg-indigo-600/80 hover:bg-indigo-600 border border-indigo-500/50 text-white py-3 rounded-full font-bold transition shadow-lg shadow-indigo-500/20"
          >
            <Plus className="w-4 h-4" /> New Note
          </button>
          <div className="mt-6 relative">
             <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
             <input 
               type="text" 
               placeholder="Search notes..." 
               value={searchQuery}
               onChange={(e) => setSearchQuery(e.target.value)}
               className="w-full pl-10 pr-4 py-2.5 bg-white/5 border border-white/10 rounded-full text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/50 text-white placeholder-slate-400 transition-all font-medium"
             />
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-2">
          <AnimatePresence>
            {filteredNotes.map(note => (
              <motion.button
                layout
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, scale: 0.95 }}
                key={note.id}
                onClick={() => setActiveNoteId(note.id)}
                className={cn(
                  "w-full text-left p-4 rounded-2xl transition-all border",
                  activeNoteId === note.id ? "bg-white/10 border-white/20 shadow-sm text-white" : "border-transparent hover:bg-white/5 text-slate-300"
                )}
              >
                <div className={cn("font-medium truncate", activeNoteId === note.id ? "text-white" : "text-slate-300")}>{note.title}</div>
                <div className="text-xs text-slate-500 mt-2 flex justify-between items-center">
                  <span>{new Date(note.lastModified).toLocaleDateString()}</span>
                  <span className={cn("px-2 py-1 rounded-md bg-white/5", activeNoteId === note.id ? "text-indigo-300" : "text-slate-400")}>{note.flashcards?.length || 0} cards</span>
                </div>
              </motion.button>
            ))}
          </AnimatePresence>
          {filteredNotes.length === 0 && (
            <div className="text-center text-sm text-slate-500 p-4">No notes found.</div>
          )}
        </div>
      </div>

      {/* Editor */}
      <div className="flex-1 flex flex-col h-full relative z-10 p-6 sm:p-8 overflow-hidden">
        {activeNote ? (
          <div className="flex-1 flex flex-col bg-white/5 backdrop-blur-md rounded-3xl border border-white/10 overflow-hidden shadow-2xl relative">
            <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-indigo-500 to-transparent opacity-50"></div>
            <div className="h-20 px-8 flex items-center justify-between border-b border-white/10 shrink-0 bg-white/5">
               <input
                  type="text"
                  value={activeNote.title}
                  onChange={(e) => updateNote(activeNote.id, { title: e.target.value })}
                  className="text-2xl font-bold text-white bg-transparent focus:outline-none w-1/2 placeholder:text-slate-500"
                  placeholder="Note Title"
               />
               <div className="flex items-center gap-3">
                 <button 
                   onClick={handleGenerateCards}
                   disabled={isGenerating || !activeNote.content.trim()}
                   className="flex items-center gap-2 px-5 py-2.5 text-sm font-bold text-slate-900 bg-white hover:bg-slate-100 rounded-full transition disabled:opacity-50 disabled:cursor-not-allowed shadow-xl shadow-white/10"
                 >
                   <Wand2 className="w-4 h-4 text-indigo-500" />
                   {isGenerating ? 'Generating...' : 'Flashcards'}
                 </button>
                 <button 
                   onClick={() => deleteNote(activeNote.id)}
                   className="p-3 text-slate-400 hover:text-red-400 hover:bg-red-500/10 rounded-full transition"
                 >
                   <Trash2 className="w-5 h-5" />
                 </button>
               </div>
            </div>
            <textarea
              value={activeNote.content}
              onChange={(e) => updateNote(activeNote.id, { content: e.target.value })}
              className="flex-1 w-full bg-transparent p-8 resize-none focus:outline-none text-white leading-relaxed font-sans placeholder-slate-600 text-lg"
              placeholder="Start typing your study notes here... AI will analyze this to generate flashcards."
            />
          </div>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 bg-white/5 backdrop-blur-md rounded-3xl border border-white/10">
             <BookOpen className="w-16 h-16 mb-4 opacity-20" />
             <p>Select a note or create a new one</p>
          </div>
        )}
      </div>
    </div>
  );
}
