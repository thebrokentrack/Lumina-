import React from 'react';
import { useAppContext } from '@/store/AppContext';
import { motion } from 'motion/react';
import { BookOpen, Brain, Timer } from 'lucide-react';

export function Dashboard({ onNavigate }: { onNavigate: (page: any) => void }) {
  const { notes, timerStats } = useAppContext();

  const totalFlashcards = notes.reduce((acc, note) => acc + (note.flashcards?.length || 0), 0);

  return (
    <div className="flex-1 overflow-y-auto p-8 lg:p-12 text-white">
      <div className="max-w-5xl mx-auto space-y-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">Welcome back! 👋</h1>
          <p className="text-slate-400 mt-2">Here's an overview of your study progress.</p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            onClick={() => onNavigate('notes')}
            className="bg-white/5 backdrop-blur-md p-8 rounded-3xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors flex flex-col relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-bl-full group-hover:bg-indigo-500/20 transition-colors"></div>
            <div className="w-12 h-12 bg-indigo-500/20 text-indigo-400 border border-indigo-500/20 rounded-xl flex items-center justify-center mb-6 z-10 w-fit">
              <BookOpen />
            </div>
            <h3 className="text-lg font-medium text-white/90 z-10">Smart Notes</h3>
            <p className="text-4xl font-light tracking-tight mt-2 text-white z-10">{notes.length}</p>
            <p className="text-sm text-slate-400 mt-1 z-10">Total Notes</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.2 }}
            onClick={() => onNavigate('flashcards')}
            className="bg-white/5 backdrop-blur-md p-8 rounded-3xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors flex flex-col relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-blue-500/10 rounded-bl-full group-hover:bg-blue-500/20 transition-colors"></div>
            <div className="w-12 h-12 bg-blue-500/20 text-blue-400 border border-blue-500/20 rounded-xl flex items-center justify-center mb-6 z-10 w-fit">
              <Brain />
            </div>
            <h3 className="text-lg font-medium text-white/90 z-10">Flashcards</h3>
            <p className="text-4xl font-light tracking-tight mt-2 text-white z-10">{totalFlashcards}</p>
            <p className="text-sm text-slate-400 mt-1 z-10">Generated Cards</p>
          </motion.div>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            onClick={() => onNavigate('focus')}
            className="bg-white/5 backdrop-blur-md p-8 rounded-3xl border border-white/10 cursor-pointer hover:bg-white/10 transition-colors flex flex-col relative overflow-hidden group"
          >
            <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/10 rounded-bl-full group-hover:bg-emerald-500/20 transition-colors"></div>
            <div className="w-12 h-12 bg-emerald-500/20 text-emerald-400 border border-emerald-500/20 rounded-xl flex items-center justify-center mb-6 z-10 w-fit">
              <Timer />
            </div>
            <h3 className="text-lg font-medium text-white/90 z-10">Focus Time</h3>
            <p className="text-4xl font-light tracking-tight mt-2 text-white z-10">{timerStats.totalMinutes} <span className="text-xl text-slate-400 font-normal">min</span></p>
            <p className="text-sm text-slate-400 mt-1 z-10">Over {timerStats.totalSessions} sessions</p>
          </motion.div>
        </div>

        <div>
          <div className="flex items-center justify-between mb-6">
             <h2 className="text-xl font-bold text-white">Recent Notes</h2>
             <button onClick={() => onNavigate('notes')} className="text-sm text-indigo-400 hover:text-indigo-300 transition-colors">View all</button>
          </div>
          {notes.length === 0 ? (
            <div className="bg-white/5 backdrop-blur-md border border-white/10 rounded-3xl p-10 text-center flex flex-col items-center">
              <p className="text-slate-400 mb-6">No notes yet. Start writing smart notes to automatically generate flashcards!</p>
              <button 
                onClick={() => onNavigate('notes')}
                className="px-6 py-3 bg-white border border-white/20 text-slate-900 rounded-full font-bold shadow-xl shadow-white/10 transition-colors hover:bg-slate-100"
              >
                Create First Note
              </button>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
               {notes.slice(0, 4).map(note => (
                 <div key={note.id} className="bg-white/5 backdrop-blur-md p-6 border border-white/10 rounded-3xl hover:bg-white/10 transition-colors cursor-pointer group" onClick={() => onNavigate('notes')}>
                    <h4 className="font-medium text-white truncate group-hover:text-indigo-300 transition-colors">{note.title}</h4>
                    <p className="text-sm text-slate-400 mt-2 line-clamp-2">{note.content || "Empty note..."}</p>
                    <div className="mt-6 pt-4 border-t border-white/5 flex items-center justify-between text-xs text-slate-500">
                      <span>{new Date(note.lastModified).toLocaleDateString()}</span>
                      <span className="flex items-center gap-1.5 px-2.5 py-1 bg-white/5 rounded-full text-indigo-300"><Brain className="w-3.5 h-3.5" /> {note.flashcards?.length || 0} cards</span>
                    </div>
                 </div>
               ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
