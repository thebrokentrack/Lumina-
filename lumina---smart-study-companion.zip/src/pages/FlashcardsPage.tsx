import React, { useState, useMemo } from 'react';
import { useAppContext } from '@/store/AppContext';
import { motion, AnimatePresence } from 'motion/react';
import { Brain, ChevronLeft, ChevronRight, RotateCcw } from 'lucide-react';
import { cn } from '@/lib/utils';

export function FlashcardsPage() {
  const { notes } = useAppContext();
  
  const allCards = useMemo(() => {
    return notes.flatMap(note => 
      (note.flashcards || []).map(card => ({ ...card, noteTitle: note.title }))
    );
  }, [notes]);

  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);

  if (allCards.length === 0) {
    return (
      <div className="flex-1 flex flex-col items-center justify-center p-8 text-center h-full text-white z-10 relative">
        <div className="w-24 h-24 bg-white/5 border border-white/10 text-indigo-400 rounded-full flex items-center justify-center mb-6 shadow-xl backdrop-blur-md">
           <Brain className="w-12 h-12" />
        </div>
        <h2 className="text-2xl font-bold text-white">No Flashcards Yet</h2>
        <p className="text-slate-400 mt-3 max-w-sm">Go to your Smart Notes and use the AI generator to automatically create flashcards from your study materials.</p>
      </div>
    );
  }

  const currentCard = allCards[currentIndex];

  const nextCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev + 1) % allCards.length);
    }, 150);
  };

  const prevCard = () => {
    setIsFlipped(false);
    setTimeout(() => {
      setCurrentIndex((prev) => (prev - 1 + allCards.length) % allCards.length);
    }, 150);
  };

  return (
    <div className="flex-1 flex flex-col items-center p-8 lg:p-12 bg-transparent text-white overflow-y-auto relative z-10">
      <div className="w-full max-w-4xl flex items-center justify-between mb-8">
        <div>
          <h1 className="text-3xl font-bold tracking-tight text-white">Memory Palace</h1>
          <p className="text-slate-400 mt-2">Card <b className="text-white">{currentIndex + 1}</b> of <b className="text-white">{allCards.length}</b></p>
        </div>
        <div className="px-4 py-2 bg-white/5 border border-white/10 text-indigo-300 rounded-full text-sm font-medium backdrop-blur-md">
          {currentCard.noteTitle}
        </div>
      </div>

      <div className="flex-1 w-full max-w-3xl flex flex-col items-center justify-center min-h-[400px]">
        {/* Flashcard 3D Container */}
        <div 
          className="relative w-full h-80 sm:h-[400px] perspective-1000 cursor-pointer group"
          onClick={() => setIsFlipped(!isFlipped)}
        >
          <motion.div
            className="w-full h-full relative preserve-3d"
            animate={{ rotateX: isFlipped ? 180 : 0 }}
            transition={{ type: "spring", stiffness: 260, damping: 20 }}
          >
            {/* Front */}
            <div className="absolute inset-0 w-full h-full backface-hidden bg-white/5 backdrop-blur-xl border border-white/20 rounded-[2rem] shadow-2xl p-10 flex flex-col items-center justify-center text-center">
               <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-blue-400 to-transparent opacity-50 rounded-t-[2rem]"></div>
               <span className="absolute top-8 left-8 text-xs font-bold uppercase tracking-widest text-slate-400">Question</span>
               <h3 className="text-3xl sm:text-4xl text-white font-medium leading-tight px-6 font-serif">
                 {currentCard.front}
               </h3>
               <div className="absolute bottom-8 text-sm text-slate-400 flex items-center gap-2 bg-white/5 px-4 py-2 rounded-full">
                 Click to turn <RotateCcw className="w-4 h-4 ml-1" />
               </div>
            </div>

            {/* Back */}
            <div 
              className="absolute inset-0 w-full h-full backface-hidden bg-indigo-600/60 backdrop-blur-2xl text-white border border-indigo-400/40 rounded-[2rem] shadow-2xl p-10 flex flex-col items-center justify-center text-center"
              style={{ transform: "rotateX(180deg)" }}
            >
               <div className="absolute top-0 inset-x-0 h-1 bg-gradient-to-r from-transparent via-white to-transparent opacity-50 rounded-t-[2rem]"></div>
               <span className="absolute top-8 left-8 text-xs font-bold uppercase tracking-widest text-indigo-200">Answer</span>
               <p className="text-2xl sm:text-3xl text-white font-medium leading-relaxed px-6">
                 {currentCard.back}
               </p>
            </div>
          </motion.div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-6 mt-16">
          <button 
            onClick={prevCard}
            className="w-14 h-14 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-white hover:bg-white/10 transition shadow-lg backdrop-blur-md"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          
          <button 
            onClick={() => setIsFlipped(!isFlipped)}
            className="px-10 py-4 bg-white border border-white/20 rounded-full font-bold text-slate-900 hover:bg-slate-100 active:bg-slate-200 transition shadow-xl shadow-white/10"
          >
            {isFlipped ? 'Hide Answer' : 'Reveal Answer'}
          </button>

          <button 
            onClick={nextCard}
            className="w-14 h-14 rounded-full bg-white/5 border border-white/20 flex items-center justify-center text-white hover:bg-white/10 transition shadow-lg backdrop-blur-md"
          >
            <ChevronRight className="w-6 h-6" />
          </button>
        </div>
      </div>
    </div>
  );
}
