import React, { useState, useRef, useEffect } from 'react';
import { useAppContext } from '@/store/AppContext';
import { askTutor } from '@/services/geminiService';
import { Send, Bot, User, Bookmark } from 'lucide-react';
import { cn } from '@/lib/utils';
import ReactMarkdown from 'react-markdown';

type Message = {
  id: string;
  role: 'user' | 'model';
  text: string;
};

export function TutorPage() {
  const { notes } = useAppContext();
  const [messages, setMessages] = useState<Message[]>([
    { id: 'initial', role: 'model', text: "Hi! I'm your AI tutor. I can help answer study questions or explain concepts from your notes. What are you studying right now?" }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);
  const [selectedNoteId, setSelectedNoteId] = useState<string>('all');

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages, isLoading]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage: Message = { id: crypto.randomUUID(), role: 'user', text: input.trim() };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setIsLoading(true);

    let context = '';
    if (selectedNoteId === 'all') {
      context = notes.map(n => `--- ${n.title} ---\n${n.content}`).join('\n\n');
    } else {
      const specificNote = notes.find(n => n.id === selectedNoteId);
      if (specificNote) context = `--- ${specificNote.title} ---\n${specificNote.content}`;
    }

    const chatHistory = messages.slice(-5).map(m => ({ role: m.role, text: m.text }));

    try {
      const responseText = await askTutor(context, userMessage.text, chatHistory);
      const botMessage: Message = { id: crypto.randomUUID(), role: 'model', text: responseText };
      setMessages(prev => [...prev, botMessage]);
    } catch (e) {
      console.error(e);
      const errorMessage: Message = { id: crypto.randomUUID(), role: 'model', text: "Sorry, I'm having trouble connecting right now." };
      setMessages(prev => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-transparent relative z-10 text-white">
      {/* Context Selector Header */}
      <div className="bg-white/5 backdrop-blur-xl border-b border-white/10 px-6 py-4 flex items-center justify-between shadow-sm z-20 shrink-0">
        <h2 className="font-bold tracking-tight flex items-center gap-3">
           <div className="w-8 h-8 rounded-lg bg-indigo-500/20 text-indigo-400 border border-indigo-500/30 flex items-center justify-center">
             <Bot className="w-5 h-5" />
           </div>
           AI Tutor
        </h2>
        <div className="flex items-center gap-3 text-sm">
          <Bookmark className="w-4 h-4 text-indigo-400" />
          <span className="text-slate-300">Context:</span>
          <select 
            value={selectedNoteId}
            onChange={e => setSelectedNoteId(e.target.value)}
            className="bg-white/10 border border-white/20 text-white rounded-lg py-1.5 px-3 focus:outline-none focus:ring-2 focus:ring-indigo-500/50 backdrop-blur-md font-medium"
          >
            <option value="all" className="bg-[#0f172a] text-white">All Notes</option>
            {notes.map(n => (
              <option key={n.id} value={n.id} className="bg-[#0f172a] text-white">{n.title}</option>
            ))}
          </select>
        </div>
      </div>

      {/* Chat Area */}
      <div 
        ref={scrollRef}
        className="flex-1 overflow-y-auto p-6 lg:p-8 space-y-6 scroll-smooth z-10"
      >
        <div className="max-w-4xl mx-auto space-y-6">
          {messages.map(msg => (
            <div key={msg.id} className={cn("flex gap-4 max-w-3xl", msg.role === 'user' ? "ml-auto flex-row-reverse" : "mr-auto")}>
              <div className={cn("w-10 h-10 rounded-full flex items-center justify-center shrink-0 border shadow-lg backdrop-blur-md", 
                msg.role === 'user' ? "bg-indigo-600 text-white border-indigo-400/50" : "bg-white/10 text-indigo-300 border-white/20")}>
                 {msg.role === 'user' ? <User className="w-5 h-5" /> : <Bot className="w-5 h-5" />}
              </div>
              <div className={cn("px-6 py-4 rounded-3xl shadow-xl backdrop-blur-md border", 
                msg.role === 'user' ? "bg-indigo-600/80 text-white rounded-tr-none border-indigo-500/50" : "bg-white/5 border-white/10 rounded-tl-none")}>
                 {msg.role === 'user' ? (
                   <p className="whitespace-pre-wrap leading-relaxed">{msg.text}</p>
                 ) : (
                   <div className="prose prose-sm md:prose-base prose-invert max-w-none">
                      <ReactMarkdown>{msg.text}</ReactMarkdown>
                   </div>
                 )}
              </div>
            </div>
          ))}
          {isLoading && (
            <div className="flex gap-4 max-w-2xl mr-auto">
               <div className="w-10 h-10 rounded-full bg-white/10 text-indigo-300 border border-white/20 shadow-lg backdrop-blur-md flex items-center justify-center shrink-0">
                 <Bot className="w-5 h-5" />
               </div>
               <div className="px-6 py-5 bg-white/5 border border-white/10 rounded-3xl rounded-tl-none shadow-xl backdrop-blur-md flex items-center gap-1.5">
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce"></span>
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '150ms' }}></span>
                  <span className="w-2 h-2 rounded-full bg-indigo-400 animate-bounce" style={{ animationDelay: '300ms' }}></span>
               </div>
            </div>
          )}
        </div>
      </div>

      {/* Input Area */}
      <div className="p-6 bg-white/5 backdrop-blur-2xl border-t border-white/10 shrink-0 z-20">
         <div className="max-w-4xl mx-auto relative flex items-center">
            <input 
              type="text"
              value={input}
              onChange={e => setInput(e.target.value)}
              onKeyDown={e => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Ask a follow-up..."
              className="w-full bg-white/5 border border-white/10 focus:border-indigo-400 focus:bg-white/10 rounded-2xl py-4 pl-6 pr-16 outline-none transition-colors text-white placeholder-slate-400 shadow-inner"
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="absolute right-3 w-10 h-10 bg-indigo-600 text-white rounded-xl flex items-center justify-center hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed transition shadow-lg shadow-indigo-500/20"
            >
              <Send className="w-5 h-5 ml-1" />
            </button>
         </div>
      </div>
    </div>
  );
}
