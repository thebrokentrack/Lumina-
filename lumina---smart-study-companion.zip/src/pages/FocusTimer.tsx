import React, { useState, useEffect, useRef } from 'react';
import { useAppContext } from '@/store/AppContext';
import { getStudyMotivation } from '@/services/geminiService';
import { motion } from 'motion/react';
import { Play, Pause, RotateCcw, Sparkles } from 'lucide-react';
import { cn } from '@/lib/utils';

type TimerMode = 'focus' | 'break';

export function FocusTimer() {
  const { addTimerSession } = useAppContext();
  
  const FOCUS_TIME = 25 * 60;
  const BREAK_TIME = 5 * 60;

  const [timeLeft, setTimeLeft] = useState(FOCUS_TIME);
  const [isRunning, setIsRunning] = useState(false);
  const [mode, setMode] = useState<TimerMode>('focus');
  const [motivation, setMotivation] = useState("");
  const [isLoadingMotivation, setIsLoadingMotivation] = useState(false);
  
  const timerRef = useRef<number | null>(null);

  useEffect(() => {
    if (isRunning) {
      timerRef.current = window.setInterval(() => {
        setTimeLeft((prev) => {
          if (prev <= 1) {
            handleComplete();
            return 0;
          }
          return prev - 1;
        });
      }, 1000);
    } else if (timerRef.current) {
      clearInterval(timerRef.current);
    }

    return () => {
      if (timerRef.current) clearInterval(timerRef.current);
    };
  }, [isRunning]);

  const handleComplete = () => {
    setIsRunning(false);
    if (mode === 'focus') {
      addTimerSession(25);
      fetchMotivation();
      setMode('break');
      setTimeLeft(BREAK_TIME);
      // Let's rely on visual/state change or standard browser APIs if needed, but alert is fine as fallback
    } else {
      setMode('focus');
      setTimeLeft(FOCUS_TIME);
    }
  };

  const fetchMotivation = async () => {
    setIsLoadingMotivation(true);
    const msg = await getStudyMotivation();
    setMotivation(msg);
    setIsLoadingMotivation(false);
  };

  const resetTimer = () => {
    setIsRunning(false);
    setTimeLeft(mode === 'focus' ? FOCUS_TIME : BREAK_TIME);
  };

  const toggleTimer = () => setIsRunning(!isRunning);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const progress = mode === 'focus' 
    ? ((FOCUS_TIME - timeLeft) / FOCUS_TIME) * 100 
    : ((BREAK_TIME - timeLeft) / BREAK_TIME) * 100;

  return (
    <div className="flex-1 flex justify-center items-center p-8 bg-slate-50 overflow-y-auto">
      <div className="max-w-md w-full flex flex-col items-center">
        
        {/* Mode Selector */}
        <div className="flex items-center gap-2 bg-slate-200/50 p-1.5 rounded-full border border-slate-200 mb-12">
           <button
             onClick={() => { setMode('focus'); setTimeLeft(FOCUS_TIME); setIsRunning(false); }}
             className={cn("px-6 py-2 rounded-full text-sm font-medium transition", mode === 'focus' ? "bg-white text-indigo-600 shadow-sm" : "text-slate-500 hover:text-slate-700")}
           >
             Focus
           </button>
           <button
             onClick={() => { setMode('break'); setTimeLeft(BREAK_TIME); setIsRunning(false); }}
             className={cn("px-6 py-2 rounded-full text-sm font-medium transition", mode === 'break' ? "bg-white text-emerald-600 shadow-sm" : "text-slate-500 hover:text-slate-700")}
           >
             Break
           </button>
        </div>

        {/* Timer Circle */}
        <div className="relative w-80 h-80 flex items-center justify-center">
           {/* SVG progress ring */}
           <svg className="absolute inset-0 w-full h-full -rotate-90" viewBox="0 0 100 100">
             <circle 
               cx="50" cy="50" r="46" 
               className="stroke-slate-200 fill-none" 
               strokeWidth="2" 
             />
             <motion.circle 
               cx="50" cy="50" r="46" 
               className={cn("fill-none", mode === 'focus' ? "stroke-indigo-500" : "stroke-emerald-500")}
               strokeWidth="4" 
               strokeLinecap="round"
               strokeDasharray="289.026"
               animate={{ strokeDashoffset: 289.026 - (289.026 * progress) / 100 }}
               transition={{ duration: 1, ease: 'linear' }}
             />
           </svg>
           
           <div className="relative z-10 flex flex-col items-center">
              <span className="text-7xl font-mono tracking-tighter text-slate-900 font-light z-10">
                {formatTime(timeLeft)}
              </span>
              <span className={cn("mt-2 text-sm font-medium uppercase tracking-widest", mode === 'focus' ? "text-indigo-500" : "text-emerald-500")}>
                {mode === 'focus' ? 'Deep Work' : 'Rest Area'}
              </span>
           </div>
        </div>

        {/* Controls */}
        <div className="flex items-center gap-6 mt-12">
            <button 
              onClick={toggleTimer}
              className={cn("w-20 h-20 rounded-full flex items-center justify-center text-white shadow-lg transition-transform hover:scale-105 active:scale-95", 
                mode === 'focus' ? "bg-indigo-600 hover:bg-indigo-700" : "bg-emerald-500 hover:bg-emerald-600")}
            >
              {isRunning ? <Pause className="w-8 h-8 fill-current" /> : <Play className="w-8 h-8 fill-current ml-1" />}
            </button>
            <button 
              onClick={resetTimer}
              className="w-12 h-12 rounded-full border-2 border-slate-200 flex items-center justify-center text-slate-400 hover:text-slate-600 hover:border-slate-300 transition"
              title="Reset Timer"
            >
              <RotateCcw className="w-5 h-5" />
            </button>
        </div>

        {/* AI Motivation Panel during break */}
        <AnimatePresence>
          {mode === 'break' && ( motivation || isLoadingMotivation ) && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -20 }}
              className="mt-12 bg-white p-6 rounded-2xl shadow-sm border border-emerald-100 relative overflow-hidden"
            >
               <div className="absolute top-0 left-0 w-1 h-full bg-emerald-400"></div>
               <div className="flex gap-3 mb-2 text-emerald-600 items-center">
                 <Sparkles className="w-4 h-4" />
                 <span className="font-semibold text-xs tracking-wider uppercase">AI Motivation</span>
               </div>
               <p className="text-slate-700 text-sm leading-relaxed italic">
                 {isLoadingMotivation ? "Consulting the muses..." : `"${motivation}"`}
               </p>
            </motion.div>
          )}
        </AnimatePresence>

      </div>
    </div>
  );
}
